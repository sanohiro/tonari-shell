import subprocess,time,statistics,sys,os
paths=sys.argv[1:]
for args in ['-a','-n -s','-n','-S -a']:
 src=f'for ((n=0;n<128;n++)); do ulimit {args}; done'
 w=[subprocess.check_output([s,'--noprofile','--norc','-c',src],stderr=subprocess.PIPE) for s in paths]
 assert w[0]==w[1]
 times=[[] for _ in paths]
 for k in range(34):
  order=[(k+i)%len(paths) for i in range(len(paths))]
  for i in order:
   t=time.perf_counter_ns(); o=subprocess.check_output([paths[i],'--noprofile','--norc','-c',src],stderr=subprocess.PIPE)
   assert o==w[i]
   if k>=3: times[i].append((time.perf_counter_ns()-t)/1e6)
 print(args,[(round(statistics.median(v),3),round(sorted(v)[29],3)) for v in times])
