"""Sample macOS ps RSS for the foreground shell at its first prompt (KiB)."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from bench_history import PROMPT, terminal

shells = list(zip(("Tonari", "Previous", "Bash"), map(Path, sys.argv[1:]), strict=True))
with tempfile.TemporaryDirectory() as directory:
    home = Path(directory)
    journal = home / ".local/state/tonari/history"
    journal.parent.mkdir(parents=True)
    for count in (0, 100000, 1000000):
        with (home / ".bash_history").open("wb") as plain, journal.open("wb") as shared:
            for i in range(count):
                entry = f": padding-{i}\n".encode()
                plain.write(entry)
                shared.write(b"1\t1\t0\t/tmp\t" + entry)
        rc = home / "rc"
        rc.write_text(f"HISTSIZE={max(1,count)}\nPS1='{PROMPT.decode()}'\n")
        samples = {name: [] for name, _ in shells}
        for i in range(12):
            for name, shell in shells[i%3:] + shells[:i%3]:
                with terminal(str(shell), home, home, rc, prompt=PROMPT) as fd:
                    pid = os.tcgetpgrp(fd)
                    listed = subprocess.check_output(["ps","-p",str(pid),"-o","rss=,comm="]).decode().strip()
                    rss, comm = listed.split(maxsplit=1)
                    if not os.path.samefile(comm, shell):raise RuntimeError((pid,comm,shell))
                    if i>=3:samples[name].append(int(rss))
        print(json.dumps(dict(entries=count,unit="KiB",samples=samples)),flush=True)
