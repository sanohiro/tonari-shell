import argparse, collections, hashlib, json, shutil, tempfile
from pathlib import Path
from audit import Audit
from bench import as_workload,benchmark,terminal_checks
from replay_budget import compare

parser=argparse.ArgumentParser()
parser.add_argument('inventory',type=Path)
parser.add_argument('bash',type=Path)
parser.add_argument('tonari',type=Path)
parser.add_argument('--runs',type=int,default=31)
args=parser.parse_args()
args.warmups=3
args.source=args.helpers=None
args.suite_runs=args.runs
args.timeout=110
rows=json.loads(args.inventory.read_text())['rows']
grouped=collections.defaultdict(list)
for group,entries in rows.items():
 for name,row in entries.items():
  for mode,data in [('batch',row.get('batch_timing',{})),*row.get('timing',{}).items()]:
   if 'bash' in data and data['tonari'][0]>data['bash'][0]:
    work=as_workload(rows,group,name)
    if mode=='batch':assert 'argv' in work
    grouped[(mode,data.get('iterations',1),json.dumps(work,sort_keys=True))].append([group,name])
with tempfile.TemporaryDirectory() as directory:
 root=Path(directory)
 bins=[]
 for name,shell in [('bash',args.bash),('current',args.tonari)]:
  path=root/name/'bash'; path.parent.mkdir();shutil.copy(shell,path);bins.append(path)
 print(json.dumps(dict(sha256=[hashlib.sha256(path.read_bytes()).hexdigest() for path in bins],runs=args.runs)),flush=True)
 a=Audit(*bins,root)
 test_class=terminal_checks(bins[1]) if any('pty_test' in k[2] for k in grouped) else None
 for (mode,count,key),items in grouped.items():
  work=json.loads(key)
  if mode=='batch':
   audits={name:Audit(path,path,root) for name,path in zip(('bash','current'),bins)}
   try:r=compare(audits,work,count,args.runs,None)
   except ValueError as error:r={'error':str(error)}
  else:
   r=benchmark(a,work,mode,args,test_class)
  print(json.dumps(dict(features=items,work=work,mode=mode,count=count,result=r)),flush=True)
