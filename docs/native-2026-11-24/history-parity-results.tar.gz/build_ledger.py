"""Rebuild the published timing ledger from the native artifacts. Run from the repo root."""
import argparse
import csv
import json
import math
from pathlib import Path
from statistics import median


def measured_rows(path, frozen, measurement):
    with path.open() as stream:
        lane = json.loads(next(stream))["lane"]
        for line in stream:
            result = json.loads(line)
            identity = result["id"]
            workload = result.get("workload") or frozen[identity]
            config = workload["lanes"][lane]
            fixed = result["fixed"]
            if fixed.get("count") != config["iterations"]:
                raise ValueError(f"{path}: missing or incorrect fixed batch for {identity}: {fixed.get('error')}")
            samples = fixed["samples_ns"]
            for group, name in config["features"]:
                row = dict(platform=lane, group=group, feature=name, witness=identity,
                           iterations=fixed["count"], samples=len(samples["current"]))
                for variant in ("current", "bash", "baseline", "direct"):
                    times = sorted(samples.get(variant, []))
                    row[variant + "_p50_ns"] = int(median(times)) if times else ""
                    row[variant + "_p95_ns"] = times[math.ceil(.95 * len(times)) - 1] if times else ""
                row["current_over_bash"] = round(median(samples["current"]) / median(samples["bash"]), 6)
                for stage in ("single", "component"):
                    series = result.get(stage, {}).get("samples_ns", {})
                    for variant in ("current", "bash"):
                        times = series.get(variant)
                        row[f"{stage}_{variant}_p50_ns"] = int(median(times)) if times else ""
                row["measurement"] = measurement
                yield row


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("output", type=Path)
    cli.add_argument("--archive", type=Path, default=Path(__file__).resolve().parent)
    args = cli.parse_args()
    manifest = Path("tests/compat/budget-2026-11-24.jsonl")
    frozen = {row["id"]: row for row in map(json.loads, manifest.read_text().splitlines())}
    sources = json.loads((args.archive / "ledger-sources.json").read_text())
    with args.output.open("w") as output:
        writer = None
        for measurement, files in sources.items():
            rows = [row for filename in files for row in measured_rows(args.archive / filename, frozen, measurement)]
            rows.sort(key=lambda row: (row["platform"], row["group"], row["feature"]))
            if not rows:
                continue
            if writer is None:
                writer = csv.DictWriter(output, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
                writer.writeheader()
            writer.writerows(rows)


if __name__ == "__main__":
    main()
